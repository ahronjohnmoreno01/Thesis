import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Card } from "../components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { cropService } from "../services/api";
import { toast } from "sonner";
import { Loader2, ArrowLeft } from "lucide-react";

export function CropInput() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    cropType: "",
    variety: "",
    plantingDate: "",
    expectedHarvestDate: "",
    area: "",
    soilType: "",
    irrigationType: "",
    temperature: "",
    humidity: "",
    rainfall: "",
    location: ""
  });

  const cropTypes = ["Rice", "Wheat", "Maize", "Cotton", "Sugarcane", "Soybean", "Pulses"];
  const soilTypes = ["Clay Loam", "Sandy Loam", "Silty Clay", "Black Soil", "Red Soil", "Alluvial"];
  const irrigationTypes = ["Drip", "Sprinkler", "Flood", "Rainfed", "Pivot"];
  const locations = ["Maharashtra", "Punjab", "Karnataka", "Gujarat", "Uttar Pradesh", "Madhya Pradesh"];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    const requiredFields = Object.keys(formData) as Array<keyof typeof formData>;
    for (const field of requiredFields) {
      if (!formData[field]) {
        toast.error("Please fill in all fields");
        return;
      }
    }

    setLoading(true);
    try {
      const cropData = {
        ...formData,
        area: parseFloat(formData.area),
        temperature: parseFloat(formData.temperature),
        humidity: parseFloat(formData.humidity),
        rainfall: parseFloat(formData.rainfall)
      };

      await cropService.submitCropData(cropData);
      toast.success("Crop data submitted successfully!");
      
      // Reset form
      setFormData({
        cropType: "",
        variety: "",
        plantingDate: "",
        expectedHarvestDate: "",
        area: "",
        soilType: "",
        irrigationType: "",
        temperature: "",
        humidity: "",
        rainfall: "",
        location: ""
      });

      // Navigate to predictions after a short delay
      setTimeout(() => {
        navigate("/predictions");
      }, 1500);
    } catch (error) {
      toast.error("Failed to submit crop data");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate("/dashboard")}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Add Crop Data</h1>
          <p className="text-gray-600 mt-1">Enter your crop details for harvest and price predictions</p>
        </div>
      </div>

      <Card className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Crop Information */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Crop Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="cropType">Crop Type *</Label>
                <Select value={formData.cropType} onValueChange={(value) => handleInputChange("cropType", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select crop type" />
                  </SelectTrigger>
                  <SelectContent>
                    {cropTypes.map(crop => (
                      <SelectItem key={crop} value={crop}>{crop}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="variety">Variety *</Label>
                <Input
                  id="variety"
                  placeholder="e.g., Basmati, HD-2967"
                  value={formData.variety}
                  onChange={(e) => handleInputChange("variety", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="plantingDate">Planting Date *</Label>
                <Input
                  id="plantingDate"
                  type="date"
                  value={formData.plantingDate}
                  onChange={(e) => handleInputChange("plantingDate", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expectedHarvestDate">Expected Harvest Date *</Label>
                <Input
                  id="expectedHarvestDate"
                  type="date"
                  value={formData.expectedHarvestDate}
                  onChange={(e) => handleInputChange("expectedHarvestDate", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="area">Area (hectares) *</Label>
                <Input
                  id="area"
                  type="number"
                  step="0.1"
                  placeholder="e.g., 2.5"
                  value={formData.area}
                  onChange={(e) => handleInputChange("area", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location *</Label>
                <Select value={formData.location} onValueChange={(value) => handleInputChange("location", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select location" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations.map(loc => (
                      <SelectItem key={loc} value={loc}>{loc}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Soil & Irrigation */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Soil & Irrigation</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="soilType">Soil Type *</Label>
                <Select value={formData.soilType} onValueChange={(value) => handleInputChange("soilType", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select soil type" />
                  </SelectTrigger>
                  <SelectContent>
                    {soilTypes.map(soil => (
                      <SelectItem key={soil} value={soil}>{soil}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="irrigationType">Irrigation Type *</Label>
                <Select value={formData.irrigationType} onValueChange={(value) => handleInputChange("irrigationType", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select irrigation type" />
                  </SelectTrigger>
                  <SelectContent>
                    {irrigationTypes.map(irrigation => (
                      <SelectItem key={irrigation} value={irrigation}>{irrigation}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Environmental Conditions */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Environmental Conditions</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="temperature">Temperature (°C) *</Label>
                <Input
                  id="temperature"
                  type="number"
                  step="0.1"
                  placeholder="e.g., 28"
                  value={formData.temperature}
                  onChange={(e) => handleInputChange("temperature", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="humidity">Humidity (%) *</Label>
                <Input
                  id="humidity"
                  type="number"
                  step="0.1"
                  placeholder="e.g., 70"
                  value={formData.humidity}
                  onChange={(e) => handleInputChange("humidity", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="rainfall">Rainfall (mm) *</Label>
                <Input
                  id="rainfall"
                  type="number"
                  step="0.1"
                  placeholder="e.g., 150"
                  value={formData.rainfall}
                  onChange={(e) => handleInputChange("rainfall", e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate("/dashboard")}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button type="submit" disabled={loading} className="flex-1">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Submit Crop Data"
              )}
            </Button>
          </div>
        </form>
      </Card>

      {/* Info Card */}
      <Card className="p-4 bg-blue-50 border-blue-200">
        <p className="text-sm text-blue-800">
          <strong>Note:</strong> This data will be used by our machine learning model to predict harvest yield and market prices. Ensure all information is accurate for best results.
        </p>
      </Card>
    </div>
  );
}
