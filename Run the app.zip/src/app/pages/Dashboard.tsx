import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { dashboardService, cropService, marketService } from "../services/api";
import { 
  TrendingUp, 
  TrendingDown, 
  Sprout, 
  LineChart, 
  DollarSign,
  Activity,
  ArrowRight
} from "lucide-react";
import { toast } from "sonner";

export function Dashboard() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalCrops: 0,
    activePredictions: 0,
    averageYield: 0,
    totalRevenue: 0,
    recentActivity: [] as Array<{ type: string; message: string; time: string }>
  });
  const [recentCrops, setRecentCrops] = useState<any[]>([]);
  const [topMarketPrices, setTopMarketPrices] = useState<any[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [statsData, cropsData, pricesData] = await Promise.all([
        dashboardService.getStatistics(),
        cropService.getCrops(),
        marketService.getMarketPrices()
      ]);
      
      setStats(statsData);
      setRecentCrops(cropsData.slice(0, 3));
      setTopMarketPrices(pricesData.slice(0, 4));
    } catch (error) {
      toast.error("Failed to load dashboard data");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-1">Welcome back! Here's your farming overview.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Crops</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{stats.totalCrops}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Sprout className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Predictions</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{stats.activePredictions}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <LineChart className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Yield (tons/ha)</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{stats.averageYield}</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Activity className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">₹{stats.totalRevenue.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <Button 
            className="h-auto py-4 flex-col gap-2"
            onClick={() => navigate("/crop-input")}
          >
            <Sprout className="w-6 h-6" />
            Add New Crop
          </Button>
          <Button 
            variant="outline"
            className="h-auto py-4 flex-col gap-2"
            onClick={() => navigate("/predictions")}
          >
            <LineChart className="w-6 h-6" />
            View Predictions
          </Button>
          <Button 
            variant="outline"
            className="h-auto py-4 flex-col gap-2"
            onClick={() => navigate("/market-prices")}
          >
            <TrendingUp className="w-6 h-6" />
            Market Prices
          </Button>
          <Button 
            variant="outline"
            className="h-auto py-4 flex-col gap-2"
            onClick={() => loadDashboardData()}
          >
            <Activity className="w-6 h-6" />
            Refresh Data
          </Button>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Crops */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Crops</h2>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/crop-input")}
            >
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
          <div className="space-y-3">
            {recentCrops.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No crops added yet</p>
            ) : (
              recentCrops.map((crop) => (
                <div 
                  key={crop.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div>
                    <p className="font-medium text-gray-900">{crop.cropType}</p>
                    <p className="text-sm text-gray-600">{crop.variety} • {crop.area} hectares</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">{crop.location}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Market Prices Summary */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Market Prices</h2>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/market-prices")}
            >
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
          <div className="space-y-3">
            {topMarketPrices.map((price) => (
              <div 
                key={price.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div>
                  <p className="font-medium text-gray-900">{price.cropType}</p>
                  <p className="text-sm text-gray-600">{price.location}</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">₹{price.currentPrice}/quintal</p>
                  <div className="flex items-center justify-end gap-1">
                    {price.change >= 0 ? (
                      <>
                        <TrendingUp className="w-3 h-3 text-green-600" />
                        <span className="text-xs text-green-600">+{price.change}%</span>
                      </>
                    ) : (
                      <>
                        <TrendingDown className="w-3 h-3 text-red-600" />
                        <span className="text-xs text-red-600">{price.change}%</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
        <div className="space-y-3">
          {stats.recentActivity.map((activity, index) => (
            <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
              <div className={`w-2 h-2 rounded-full mt-2 ${
                activity.type === 'prediction' ? 'bg-blue-500' :
                activity.type === 'price' ? 'bg-green-500' : 'bg-purple-500'
              }`} />
              <div className="flex-1">
                <p className="text-gray-900">{activity.message}</p>
                <p className="text-sm text-gray-500">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
