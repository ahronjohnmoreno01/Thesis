import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { marketService, type MarketPrice } from "../services/api";
import { toast } from "sonner";
import { ArrowLeft, TrendingUp, TrendingDown, RefreshCw, BarChart3 } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export function MarketPrices() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [prices, setPrices] = useState<MarketPrice[]>([]);
  const [selectedCrop, setSelectedCrop] = useState<string>("");
  const [priceHistory, setPriceHistory] = useState<{ date: string; price: number }[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  useEffect(() => {
    loadPrices();
  }, []);

  const loadPrices = async () => {
    try {
      const data = await marketService.getMarketPrices();
      setPrices(data);
      if (data.length > 0 && !selectedCrop) {
        setSelectedCrop(data[0].cropType);
        loadPriceHistory(data[0].cropType);
      }
    } catch (error) {
      toast.error("Failed to load market prices");
    } finally {
      setLoading(false);
    }
  };

  const refreshPrices = async () => {
    setRefreshing(true);
    try {
      await loadPrices();
      if (selectedCrop) {
        await loadPriceHistory(selectedCrop);
      }
      toast.success("Market prices updated!");
    } finally {
      setRefreshing(false);
    }
  };

  const loadPriceHistory = async (cropType: string) => {
    setLoadingHistory(true);
    try {
      const history = await marketService.getPriceHistory(cropType);
      setPriceHistory(history);
    } catch (error) {
      toast.error("Failed to load price history");
    } finally {
      setLoadingHistory(false);
    }
  };

  const handleCropSelect = (cropType: string) => {
    setSelectedCrop(cropType);
    loadPriceHistory(cropType);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate("/dashboard")}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-gray-900">Market Prices</h1>
          <p className="text-gray-600 mt-1">Real-time crop prices across markets</p>
        </div>
        <Button 
          variant="outline"
          onClick={refreshPrices}
          disabled={refreshing}
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Price Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {prices.map((price) => (
          <Card 
            key={price.id} 
            className={`p-5 cursor-pointer transition-all ${
              selectedCrop === price.cropType 
                ? 'ring-2 ring-green-600 border-green-600' 
                : 'hover:shadow-md'
            }`}
            onClick={() => handleCropSelect(price.cropType)}
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="font-semibold text-gray-900 text-lg">{price.cropType}</p>
                <p className="text-sm text-gray-600">{price.location}</p>
              </div>
              {price.change >= 0 ? (
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {price.change}%
                </Badge>
              ) : (
                <Badge className="bg-red-100 text-red-800 border-red-200">
                  <TrendingDown className="w-3 h-3 mr-1" />
                  {price.change}%
                </Badge>
              )}
            </div>
            
            <div className="mb-2">
              <p className="text-3xl font-bold text-gray-900">
                ₹{price.currentPrice}
              </p>
              <p className="text-xs text-gray-600">per quintal</p>
            </div>

            <div className="flex items-center justify-between text-xs text-gray-500 pt-3 border-t border-gray-100">
              <span>Previous: ₹{price.previousPrice}</span>
              <span>{new Date(price.lastUpdated).toLocaleDateString()}</span>
            </div>
          </Card>
        ))}
      </div>

      {/* Price History Chart */}
      {selectedCrop && (
        <Card className="p-6">
          <Tabs defaultValue="chart" className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">
                  {selectedCrop} - Price History
                </h2>
                <p className="text-sm text-gray-600 mt-1">
                  Last 30 days price trend
                </p>
              </div>
              <TabsList>
                <TabsTrigger value="chart">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Chart
                </TabsTrigger>
                <TabsTrigger value="table">
                  Table
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="chart" className="space-y-4">
              {loadingHistory ? (
                <div className="flex items-center justify-center h-80">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                </div>
              ) : (
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={priceHistory}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis 
                        dataKey="date" 
                        tick={{ fontSize: 12 }}
                        tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      />
                      <YAxis 
                        tick={{ fontSize: 12 }}
                        label={{ value: 'Price (₹)', angle: -90, position: 'insideLeft' }}
                      />
                      <Tooltip 
                        formatter={(value) => [`₹${value}`, 'Price']}
                        labelFormatter={(label) => new Date(label).toLocaleDateString()}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="price" 
                        stroke="#16a34a" 
                        strokeWidth={2}
                        dot={{ r: 3 }}
                        activeDot={{ r: 5 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
            </TabsContent>

            <TabsContent value="table" className="space-y-4">
              {loadingHistory ? (
                <div className="flex items-center justify-center h-80">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                </div>
              ) : (
                <div className="max-h-80 overflow-y-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 sticky top-0">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Date</th>
                        <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Price (₹)</th>
                        <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Change</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {priceHistory.map((item, index) => {
                        const prevPrice = index < priceHistory.length - 1 ? priceHistory[index + 1].price : item.price;
                        const change = ((item.price - prevPrice) / prevPrice * 100).toFixed(2);
                        return (
                          <tr key={item.date} className="hover:bg-gray-50">
                            <td className="px-4 py-3 text-sm text-gray-900">
                              {new Date(item.date).toLocaleDateString()}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-900 text-right font-medium">
                              ₹{item.price}
                            </td>
                            <td className="px-4 py-3 text-sm text-right">
                              {index < priceHistory.length - 1 && (
                                <span className={parseFloat(change) >= 0 ? 'text-green-600' : 'text-red-600'}>
                                  {parseFloat(change) >= 0 ? '+' : ''}{change}%
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </Card>
      )}

      {/* Market Insights */}
      <Card className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <TrendingUp className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-blue-900 mb-2">Market Insights</h3>
            <div className="space-y-2 text-sm text-blue-800">
              <p>
                • <strong>Best performing:</strong> {prices.reduce((max, p) => p.change > max.change ? p : max, prices[0])?.cropType} 
                (+{prices.reduce((max, p) => p.change > max.change ? p : max, prices[0])?.change}%)
              </p>
              <p>
                • <strong>Highest price:</strong> {prices.reduce((max, p) => p.currentPrice > max.currentPrice ? p : max, prices[0])?.cropType} 
                (₹{prices.reduce((max, p) => p.currentPrice > max.currentPrice ? p : max, prices[0])?.currentPrice}/quintal)
              </p>
              <p>
                • <strong>Market average:</strong> ₹{Math.round(prices.reduce((sum, p) => sum + p.currentPrice, 0) / prices.length)}/quintal
              </p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
