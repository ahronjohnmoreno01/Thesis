import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { predictionService, cropService, type Prediction, type CropData } from "../services/api";
import { toast } from "sonner";
import { ArrowLeft, TrendingUp, Sparkles, AlertCircle, CheckCircle } from "lucide-react";

export function PredictionResults() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [crops, setCrops] = useState<CropData[]>([]);
  const [generatingPrediction, setGeneratingPrediction] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [predictionsData, cropsData] = await Promise.all([
        predictionService.getAllPredictions(),
        cropService.getCrops()
      ]);
      setPredictions(predictionsData);
      setCrops(cropsData);
    } catch (error) {
      toast.error("Failed to load predictions");
    } finally {
      setLoading(false);
    }
  };

  const generatePrediction = async (cropId: string) => {
    setGeneratingPrediction(cropId);
    try {
      const prediction = await predictionService.getPrediction(cropId);
      setPredictions(prev => [prediction, ...prev]);
      toast.success("Prediction generated successfully!");
    } catch (error) {
      toast.error("Failed to generate prediction");
    } finally {
      setGeneratingPrediction(null);
    }
  };

  const getCropDetails = (cropId: string) => {
    return crops.find(c => c.id === cropId);
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return "text-green-600";
    if (confidence >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getConfidenceLabel = (confidence: number) => {
    if (confidence >= 80) return "High";
    if (confidence >= 60) return "Medium";
    return "Low";
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate("/dashboard")}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-gray-900">Harvest & Price Predictions</h1>
          <p className="text-gray-600 mt-1">AI-powered predictions for your crops</p>
        </div>
        <Button onClick={() => navigate("/crop-input")}>
          <Sparkles className="w-4 h-4 mr-2" />
          Add Crop
        </Button>
      </div>

      {/* Info Banner */}
      <Card className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
          <div>
            <p className="text-sm text-blue-900 font-medium">
              Machine Learning Model Integration
            </p>
            <p className="text-xs text-blue-700 mt-1">
              Predictions are generated using environmental factors, soil data, and historical patterns. 
              The system is ready for trained model (.pkl or .h5) integration via the backend API.
            </p>
          </div>
        </div>
      </Card>

      {/* Crops Awaiting Predictions */}
      {crops.length > 0 && (
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Generate New Predictions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {crops.map((crop) => {
              const hasPrediction = predictions.some(p => p.cropId === crop.id);
              return (
                <div key={crop.id} className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-semibold text-gray-900">{crop.cropType}</p>
                      <p className="text-sm text-gray-600">{crop.variety}</p>
                    </div>
                    {hasPrediction && (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Predicted
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mb-3">
                    {crop.area} ha • {crop.location}
                  </p>
                  <Button 
                    size="sm" 
                    className="w-full"
                    onClick={() => generatePrediction(crop.id!)}
                    disabled={generatingPrediction === crop.id}
                  >
                    {generatingPrediction === crop.id ? (
                      <>
                        <div className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Generate Prediction
                      </>
                    )}
                  </Button>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Predictions List */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Predictions</h2>
        {predictions.length === 0 ? (
          <Card className="p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-600 mb-4">No predictions generated yet</p>
            <Button onClick={() => navigate("/crop-input")}>
              Add Your First Crop
            </Button>
          </Card>
        ) : (
          <div className="space-y-4">
            {predictions.map((prediction) => {
              const crop = getCropDetails(prediction.cropId);
              return (
                <Card key={prediction.id} className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
                    {/* Left Section */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-xl font-semibold text-gray-900">{prediction.cropType}</h3>
                          {crop && (
                            <p className="text-sm text-gray-600 mt-1">
                              {crop.variety} • {crop.area} hectares • {crop.location}
                            </p>
                          )}
                        </div>
                        <Badge 
                          variant="outline" 
                          className={`${getConfidenceColor(prediction.confidence)} border-current`}
                        >
                          {getConfidenceLabel(prediction.confidence)} Confidence
                        </Badge>
                      </div>

                      {/* Prediction Results */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                        <div className="p-4 bg-green-50 rounded-lg">
                          <p className="text-sm text-green-800 font-medium">Predicted Yield</p>
                          <p className="text-2xl font-bold text-green-900 mt-1">
                            {prediction.predictedYield} tons
                          </p>
                          <p className="text-xs text-green-700 mt-1">per hectare</p>
                        </div>

                        <div className="p-4 bg-blue-50 rounded-lg">
                          <p className="text-sm text-blue-800 font-medium">Predicted Price</p>
                          <p className="text-2xl font-bold text-blue-900 mt-1">
                            ₹{prediction.predictedPrice}
                          </p>
                          <p className="text-xs text-blue-700 mt-1">per quintal</p>
                        </div>
                      </div>

                      {/* Confidence Factors */}
                      <div className="space-y-3">
                        <p className="text-sm font-medium text-gray-700">Confidence Factors:</p>
                        
                        <div>
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span className="text-gray-600">Weather Conditions</span>
                            <span className="font-medium text-gray-900">{prediction.factors.weather}%</span>
                          </div>
                          <Progress value={prediction.factors.weather} className="h-2" />
                        </div>

                        <div>
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span className="text-gray-600">Soil Quality</span>
                            <span className="font-medium text-gray-900">{prediction.factors.soil}%</span>
                          </div>
                          <Progress value={prediction.factors.soil} className="h-2" />
                        </div>

                        <div>
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span className="text-gray-600">Historical Data</span>
                            <span className="font-medium text-gray-900">{prediction.factors.historical}%</span>
                          </div>
                          <Progress value={prediction.factors.historical} className="h-2" />
                        </div>
                      </div>

                      <p className="text-xs text-gray-500 mt-4">
                        Generated on {new Date(prediction.timestamp).toLocaleString()}
                      </p>
                    </div>

                    {/* Right Section - Estimated Revenue */}
                    {crop && (
                      <div className="lg:w-64 p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border border-purple-200">
                        <p className="text-sm text-purple-800 font-medium mb-2">Estimated Revenue</p>
                        <p className="text-3xl font-bold text-purple-900 mb-1">
                          ₹{Math.round((prediction.predictedYield * crop.area * prediction.predictedPrice) / 100).toLocaleString()}
                        </p>
                        <p className="text-xs text-purple-700">
                          Based on {prediction.predictedYield * crop.area} tons total yield
                        </p>
                        <div className="mt-4 pt-4 border-t border-purple-200">
                          <p className="text-xs text-purple-800 font-medium mb-2">Harvest Timeline</p>
                          <p className="text-xs text-purple-700">
                            Expected: {new Date(crop.expectedHarvestDate).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
