import { Outlet, useLocation, useNavigate } from "react-router";
import { Menu, X } from "lucide-react";
import { useState, useEffect } from "react";
import { Button } from "../components/ui/button";

export function Root() {
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Check if user is on auth pages (login/register)
  const isAuthPage = location.pathname === "/" || location.pathname === "/register";

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation - only show on authenticated pages */}
      {!isAuthPage && (
        <nav className="bg-white shadow-sm border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              {/* Logo */}
              <div className="flex items-center">
                <div className="flex-shrink-0 flex items-center gap-2">
                  <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-lg">SH</span>
                  </div>
                  <span className="text-xl font-semibold text-gray-900 hidden sm:block">
                    Smart Harvest
                  </span>
                </div>
              </div>

              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center gap-1">
                <Button
                  variant={location.pathname === "/dashboard" ? "default" : "ghost"}
                  onClick={() => navigate("/dashboard")}
                >
                  Dashboard
                </Button>
                <Button
                  variant={location.pathname === "/crop-input" ? "default" : "ghost"}
                  onClick={() => navigate("/crop-input")}
                >
                  Add Crop
                </Button>
                <Button
                  variant={location.pathname === "/predictions" ? "default" : "ghost"}
                  onClick={() => navigate("/predictions")}
                >
                  Predictions
                </Button>
                <Button
                  variant={location.pathname === "/market-prices" ? "default" : "ghost"}
                  onClick={() => navigate("/market-prices")}
                >
                  Market Prices
                </Button>
                <Button variant="ghost" onClick={handleLogout}>
                  Logout
                </Button>
              </div>

              {/* Mobile menu button */}
              <div className="md:hidden">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                >
                  {mobileMenuOpen ? (
                    <X className="h-6 w-6" />
                  ) : (
                    <Menu className="h-6 w-6" />
                  )}
                </Button>
              </div>
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-gray-200">
              <div className="px-2 pt-2 pb-3 space-y-1">
                <Button
                  variant={location.pathname === "/dashboard" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => navigate("/dashboard")}
                >
                  Dashboard
                </Button>
                <Button
                  variant={location.pathname === "/crop-input" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => navigate("/crop-input")}
                >
                  Add Crop
                </Button>
                <Button
                  variant={location.pathname === "/predictions" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => navigate("/predictions")}
                >
                  Predictions
                </Button>
                <Button
                  variant={location.pathname === "/market-prices" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => navigate("/market-prices")}
                >
                  Market Prices
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={handleLogout}
                >
                  Logout
                </Button>
              </div>
            </div>
          )}
        </nav>
      )}

      {/* Main Content */}
      <main className={isAuthPage ? "" : "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"}>
        <Outlet />
      </main>
    </div>
  );
}
