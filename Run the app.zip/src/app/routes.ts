import { createBrowserRouter } from "react-router";
import { Root } from "./pages/Root";
import { Login } from "./pages/Login";
import { Register } from "./pages/Register";
import { Dashboard } from "./pages/Dashboard";
import { CropInput } from "./pages/CropInput";
import { PredictionResults } from "./pages/PredictionResults";
import { MarketPrices } from "./pages/MarketPrices";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Login },
      { path: "register", Component: Register },
      { path: "dashboard", Component: Dashboard },
      { path: "crop-input", Component: CropInput },
      { path: "predictions", Component: PredictionResults },
      { path: "market-prices", Component: MarketPrices },
    ],
  },
]);
