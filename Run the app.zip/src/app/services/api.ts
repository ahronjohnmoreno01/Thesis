// Mock API Service Layer - Ready for Backend Integration
// This demonstrates how the ML model and backend APIs will be integrated

interface User {
  id: string;
  name: string;
  email: string;
  role: 'farmer' | 'admin';
}

interface CropData {
  id?: string;
  cropType: string;
  variety: string;
  plantingDate: string;
  expectedHarvestDate: string;
  area: number;
  soilType: string;
  irrigationType: string;
  temperature: number;
  humidity: number;
  rainfall: number;
  location: string;
}

interface Prediction {
  id: string;
  cropId: string;
  cropType: string;
  predictedYield: number;
  predictedPrice: number;
  confidence: number;
  timestamp: string;
  factors: {
    weather: number;
    soil: number;
    historical: number;
  };
}

interface MarketPrice {
  id: string;
  cropType: string;
  currentPrice: number;
  previousPrice: number;
  change: number;
  location: string;
  lastUpdated: string;
}

// Mock user storage
let currentUser: User | null = null;

// Mock data storage
const mockCrops: CropData[] = [
  {
    id: '1',
    cropType: 'Rice',
    variety: 'Basmati',
    plantingDate: '2026-01-15',
    expectedHarvestDate: '2026-05-15',
    area: 2.5,
    soilType: 'Clay Loam',
    irrigationType: 'Drip',
    temperature: 28,
    humidity: 70,
    rainfall: 150,
    location: 'Maharashtra'
  },
  {
    id: '2',
    cropType: 'Wheat',
    variety: 'HD-2967',
    plantingDate: '2025-11-01',
    expectedHarvestDate: '2026-04-01',
    area: 3.0,
    soilType: 'Sandy Loam',
    irrigationType: 'Sprinkler',
    temperature: 22,
    humidity: 60,
    rainfall: 80,
    location: 'Punjab'
  }
];

const mockPredictions: Prediction[] = [
  {
    id: '1',
    cropId: '1',
    cropType: 'Rice',
    predictedYield: 4.2,
    predictedPrice: 1850,
    confidence: 87,
    timestamp: '2026-03-01T10:00:00Z',
    factors: { weather: 85, soil: 90, historical: 86 }
  },
  {
    id: '2',
    cropId: '2',
    cropType: 'Wheat',
    predictedYield: 3.8,
    predictedPrice: 2100,
    confidence: 82,
    timestamp: '2026-03-02T14:30:00Z',
    factors: { weather: 80, soil: 85, historical: 81 }
  }
];

const mockMarketPrices: MarketPrice[] = [
  {
    id: '1',
    cropType: 'Rice',
    currentPrice: 1820,
    previousPrice: 1750,
    change: 4.0,
    location: 'Maharashtra',
    lastUpdated: '2026-03-03T09:00:00Z'
  },
  {
    id: '2',
    cropType: 'Wheat',
    currentPrice: 2050,
    previousPrice: 2100,
    change: -2.4,
    location: 'Punjab',
    lastUpdated: '2026-03-03T09:00:00Z'
  },
  {
    id: '3',
    cropType: 'Maize',
    currentPrice: 1650,
    previousPrice: 1600,
    change: 3.1,
    location: 'Karnataka',
    lastUpdated: '2026-03-03T09:00:00Z'
  },
  {
    id: '4',
    cropType: 'Cotton',
    currentPrice: 5800,
    previousPrice: 5950,
    change: -2.5,
    location: 'Gujarat',
    lastUpdated: '2026-03-03T09:00:00Z'
  }
];

// Simulated delay for API calls
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Authentication APIs
export const authService = {
  async login(email: string, password: string): Promise<User> {
    await delay(800);
    // Mock authentication - in production, this would verify credentials with backend
    currentUser = {
      id: '1',
      name: 'John Farmer',
      email: email,
      role: 'farmer'
    };
    return currentUser;
  },

  async register(name: string, email: string, password: string): Promise<User> {
    await delay(800);
    // Mock registration - in production, this would create user in database
    currentUser = {
      id: Date.now().toString(),
      name: name,
      email: email,
      role: 'farmer'
    };
    return currentUser;
  },

  async getCurrentUser(): Promise<User | null> {
    return currentUser;
  },

  logout() {
    currentUser = null;
  }
};

// Crop Data APIs
export const cropService = {
  async submitCropData(cropData: CropData): Promise<CropData> {
    await delay(500);
    const newCrop = {
      ...cropData,
      id: Date.now().toString()
    };
    mockCrops.push(newCrop);
    return newCrop;
  },

  async getCrops(): Promise<CropData[]> {
    await delay(300);
    return mockCrops;
  }
};

// ML Prediction APIs
// This demonstrates how a trained model will be integrated
export const predictionService = {
  /**
   * This function will call the backend ML prediction endpoint
   * Backend will load the trained model (.pkl or .h5 file) and return predictions
   * 
   * Backend Implementation (Python/FastAPI):
   * 
   * import pickle
   * from fastapi import FastAPI
   * import numpy as np
   * 
   * # Load trained model
   * model = pickle.load(open('models/harvest_model.pkl', 'rb'))
   * 
   * @app.post("/api/predict")
   * async def predict(crop_data: CropData):
   *     # Prepare features for model
   *     features = prepare_features(crop_data)
   *     
   *     # Make prediction
   *     yield_prediction = model.predict_yield(features)
   *     price_prediction = model.predict_price(features)
   *     confidence = model.predict_proba(features).max()
   *     
   *     return {
   *         "predicted_yield": yield_prediction,
   *         "predicted_price": price_prediction,
   *         "confidence": confidence
   *     }
   */
  async getPrediction(cropId: string): Promise<Prediction> {
    await delay(1000);
    
    // Mock prediction logic - simulates ML model output
    const crop = mockCrops.find(c => c.id === cropId);
    if (!crop) throw new Error('Crop not found');

    // Simulate complex ML calculations
    const weatherFactor = (crop.temperature * 0.4 + crop.humidity * 0.3 + crop.rainfall * 0.3) / 100;
    const soilFactor = crop.soilType === 'Clay Loam' ? 0.9 : 0.85;
    const historicalFactor = 0.86;

    const baseYield = crop.area * 1.5;
    const predictedYield = baseYield * weatherFactor * soilFactor * historicalFactor;

    const basePriceMap: { [key: string]: number } = {
      'Rice': 1800,
      'Wheat': 2000,
      'Maize': 1600,
      'Cotton': 5500
    };

    const predictedPrice = (basePriceMap[crop.cropType] || 1500) * (0.9 + Math.random() * 0.2);

    return {
      id: Date.now().toString(),
      cropId: cropId,
      cropType: crop.cropType,
      predictedYield: Math.round(predictedYield * 100) / 100,
      predictedPrice: Math.round(predictedPrice),
      confidence: Math.round((weatherFactor + soilFactor + historicalFactor) / 3 * 100),
      timestamp: new Date().toISOString(),
      factors: {
        weather: Math.round(weatherFactor * 100),
        soil: Math.round(soilFactor * 100),
        historical: Math.round(historicalFactor * 100)
      }
    };
  },

  async getAllPredictions(): Promise<Prediction[]> {
    await delay(300);
    return mockPredictions;
  }
};

// Market Price APIs
export const marketService = {
  async getMarketPrices(): Promise<MarketPrice[]> {
    await delay(500);
    return mockMarketPrices;
  },

  async getPriceHistory(cropType: string): Promise<{ date: string; price: number }[]> {
    await delay(400);
    // Mock historical price data
    const basePrice = mockMarketPrices.find(p => p.cropType === cropType)?.currentPrice || 1500;
    const history = [];
    
    for (let i = 30; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const variation = (Math.random() - 0.5) * 200;
      history.push({
        date: date.toISOString().split('T')[0],
        price: Math.round(basePrice + variation)
      });
    }
    
    return history;
  }
};

// Dashboard Statistics API
export const dashboardService = {
  async getStatistics(): Promise<{
    totalCrops: number;
    activePredictions: number;
    averageYield: number;
    totalRevenue: number;
    recentActivity: Array<{ type: string; message: string; time: string }>;
  }> {
    await delay(400);
    
    return {
      totalCrops: mockCrops.length,
      activePredictions: mockPredictions.length,
      averageYield: 4.0,
      totalRevenue: 125000,
      recentActivity: [
        { type: 'prediction', message: 'New prediction generated for Rice crop', time: '2 hours ago' },
        { type: 'price', message: 'Market price updated for Wheat', time: '4 hours ago' },
        { type: 'crop', message: 'New crop data submitted', time: '1 day ago' }
      ]
    };
  }
};

export type { User, CropData, Prediction, MarketPrice };
