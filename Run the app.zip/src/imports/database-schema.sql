-- Smart Harvest Database Schema
-- PostgreSQL 14+
-- Run this file: psql -U postgres -d smart_harvest -f schema.sql

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================================================
-- Users Table
-- =============================================================================

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'farmer' CHECK (role IN ('farmer', 'admin', 'expert')),
    phone VARCHAR(20),
    location VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- =============================================================================
-- Crops Table
-- =============================================================================

CREATE TABLE crops (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    crop_type VARCHAR(100) NOT NULL,
    variety VARCHAR(100) NOT NULL,
    planting_date DATE NOT NULL,
    expected_harvest_date DATE NOT NULL,
    actual_harvest_date DATE,
    area DECIMAL(10, 2) NOT NULL CHECK (area > 0),
    soil_type VARCHAR(100) NOT NULL,
    irrigation_type VARCHAR(100) NOT NULL,
    temperature DECIMAL(5, 2),
    humidity DECIMAL(5, 2),
    rainfall DECIMAL(7, 2),
    location VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'planted' CHECK (status IN ('planted', 'growing', 'harvested')),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_crops_user_id ON crops(user_id);
CREATE INDEX idx_crops_type ON crops(crop_type);
CREATE INDEX idx_crops_location ON crops(location);
CREATE INDEX idx_crops_status ON crops(status);
CREATE INDEX idx_crops_harvest_date ON crops(expected_harvest_date);

-- =============================================================================
-- Predictions Table
-- =============================================================================

CREATE TABLE predictions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    crop_id UUID NOT NULL REFERENCES crops(id) ON DELETE CASCADE,
    predicted_yield DECIMAL(10, 2) NOT NULL,
    predicted_price DECIMAL(10, 2) NOT NULL,
    confidence DECIMAL(5, 2) NOT NULL CHECK (confidence >= 0 AND confidence <= 100),
    weather_factor DECIMAL(5, 2),
    soil_factor DECIMAL(5, 2),
    historical_factor DECIMAL(5, 2),
    model_version VARCHAR(50),
    algorithm_used VARCHAR(100),
    features_used JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_predictions_crop_id ON predictions(crop_id);
CREATE INDEX idx_predictions_created_at ON predictions(created_at DESC);
CREATE INDEX idx_predictions_confidence ON predictions(confidence);

-- =============================================================================
-- Market Prices Table
-- =============================================================================

CREATE TABLE market_prices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    crop_type VARCHAR(100) NOT NULL,
    current_price DECIMAL(10, 2) NOT NULL,
    previous_price DECIMAL(10, 2),
    location VARCHAR(255) NOT NULL,
    market_name VARCHAR(255),
    price_date DATE NOT NULL,
    source VARCHAR(255),
    quality_grade VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_market_prices_crop_date ON market_prices(crop_type, price_date DESC);
CREATE INDEX idx_market_prices_location ON market_prices(location);
CREATE INDEX idx_market_prices_source ON market_prices(source);

-- =============================================================================
-- Historical Harvest Data (for ML training)
-- =============================================================================

CREATE TABLE historical_harvest_data (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    crop_type VARCHAR(100) NOT NULL,
    variety VARCHAR(100),
    actual_yield DECIMAL(10, 2) NOT NULL,
    actual_price DECIMAL(10, 2),
    area DECIMAL(10, 2) NOT NULL,
    soil_type VARCHAR(100),
    irrigation_type VARCHAR(100),
    temperature DECIMAL(5, 2),
    humidity DECIMAL(5, 2),
    rainfall DECIMAL(7, 2),
    location VARCHAR(255),
    harvest_date DATE NOT NULL,
    planting_date DATE,
    season VARCHAR(50),
    fertilizer_used JSONB,
    pesticide_used JSONB,
    data_source VARCHAR(255),
    verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_historical_crop_type ON historical_harvest_data(crop_type);
CREATE INDEX idx_historical_location ON historical_harvest_data(location);
CREATE INDEX idx_historical_harvest_date ON historical_harvest_data(harvest_date);
CREATE INDEX idx_historical_verified ON historical_harvest_data(verified);

-- =============================================================================
-- Model Training Logs
-- =============================================================================

CREATE TABLE model_training_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    model_type VARCHAR(100) NOT NULL CHECK (model_type IN ('yield_prediction', 'price_prediction')),
    model_version VARCHAR(50) NOT NULL,
    algorithm VARCHAR(100) NOT NULL,
    training_accuracy DECIMAL(5, 4),
    validation_accuracy DECIMAL(5, 4),
    test_accuracy DECIMAL(5, 4),
    r2_score DECIMAL(5, 4),
    mae DECIMAL(10, 4),
    rmse DECIMAL(10, 4),
    training_samples INTEGER,
    hyperparameters JSONB,
    feature_importance JSONB,
    training_duration_seconds INTEGER,
    model_file_path VARCHAR(500),
    trained_by UUID REFERENCES users(id),
    training_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT
);

CREATE INDEX idx_training_logs_model_type ON model_training_logs(model_type);
CREATE INDEX idx_training_logs_version ON model_training_logs(model_version);
CREATE INDEX idx_training_logs_active ON model_training_logs(is_active);

-- =============================================================================
-- Weather Data (optional, for external API integration)
-- =============================================================================

CREATE TABLE weather_data (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    location VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    temperature DECIMAL(5, 2),
    humidity DECIMAL(5, 2),
    rainfall DECIMAL(7, 2),
    wind_speed DECIMAL(5, 2),
    weather_condition VARCHAR(100),
    recorded_at TIMESTAMP NOT NULL,
    source VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_weather_location_date ON weather_data(location, recorded_at DESC);

-- =============================================================================
-- User Activity Logs
-- =============================================================================

CREATE TABLE activity_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    activity_type VARCHAR(100) NOT NULL,
    description TEXT,
    metadata JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_activity_logs_user_id ON activity_logs(user_id);
CREATE INDEX idx_activity_logs_type ON activity_logs(activity_type);
CREATE INDEX idx_activity_logs_created_at ON activity_logs(created_at DESC);

-- =============================================================================
-- Views for Common Queries
-- =============================================================================

-- View: Latest Market Prices
CREATE VIEW v_latest_market_prices AS
SELECT DISTINCT ON (crop_type, location)
    crop_type,
    current_price,
    previous_price,
    CASE 
        WHEN previous_price > 0 THEN 
            ROUND(((current_price - previous_price) / previous_price * 100)::NUMERIC, 2)
        ELSE 0
    END as price_change_percent,
    location,
    market_name,
    price_date,
    source
FROM market_prices
ORDER BY crop_type, location, price_date DESC;

-- View: User Statistics
CREATE VIEW v_user_statistics AS
SELECT 
    u.id as user_id,
    u.name,
    u.email,
    COUNT(DISTINCT c.id) as total_crops,
    COUNT(DISTINCT p.id) as total_predictions,
    AVG(p.predicted_yield) as avg_predicted_yield,
    MAX(c.created_at) as last_crop_added
FROM users u
LEFT JOIN crops c ON u.id = c.user_id
LEFT JOIN predictions p ON c.id = p.crop_id
GROUP BY u.id, u.name, u.email;

-- View: Crop Performance
CREATE VIEW v_crop_performance AS
SELECT 
    c.id as crop_id,
    c.crop_type,
    c.variety,
    c.location,
    c.area,
    p.predicted_yield,
    p.predicted_price,
    p.confidence,
    CASE 
        WHEN p.predicted_yield IS NOT NULL THEN
            ROUND((p.predicted_yield * c.area * p.predicted_price / 100)::NUMERIC, 2)
        ELSE NULL
    END as estimated_revenue,
    c.expected_harvest_date,
    c.status
FROM crops c
LEFT JOIN predictions p ON c.id = p.crop_id;

-- =============================================================================
-- Functions and Triggers
-- =============================================================================

-- Function: Update timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger: Auto-update updated_at for users
CREATE TRIGGER trigger_update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Trigger: Auto-update updated_at for crops
CREATE TRIGGER trigger_update_crops_updated_at
    BEFORE UPDATE ON crops
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Function: Calculate average yield for crop type
CREATE OR REPLACE FUNCTION get_avg_yield_for_crop(p_crop_type VARCHAR)
RETURNS DECIMAL AS $$
DECLARE
    avg_yield DECIMAL;
BEGIN
    SELECT AVG(actual_yield) INTO avg_yield
    FROM historical_harvest_data
    WHERE crop_type = p_crop_type
    AND verified = TRUE;
    
    RETURN COALESCE(avg_yield, 0);
END;
$$ LANGUAGE plpgsql;

-- Function: Get market price trend
CREATE OR REPLACE FUNCTION get_price_trend(
    p_crop_type VARCHAR,
    p_location VARCHAR,
    p_days INTEGER DEFAULT 30
)
RETURNS TABLE (
    date DATE,
    avg_price DECIMAL,
    min_price DECIMAL,
    max_price DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        price_date as date,
        AVG(current_price) as avg_price,
        MIN(current_price) as min_price,
        MAX(current_price) as max_price
    FROM market_prices
    WHERE crop_type = p_crop_type
    AND location = p_location
    AND price_date >= CURRENT_DATE - p_days
    GROUP BY price_date
    ORDER BY price_date ASC;
END;
$$ LANGUAGE plpgsql;

-- =============================================================================
-- Initial Data (Sample/Test Data)
-- =============================================================================

-- Insert sample user
INSERT INTO users (name, email, password_hash, role, location) VALUES
('Demo Farmer', 'demo@farmer.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5/JCMXaEWGJy2', 'farmer', 'Maharashtra'),
('Admin User', 'admin@smartharvest.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5/JCMXaEWGJy2', 'admin', 'Mumbai');

-- Insert sample market prices
INSERT INTO market_prices (crop_type, current_price, previous_price, location, market_name, price_date, source) VALUES
('Rice', 1820, 1750, 'Maharashtra', 'Pune APMC', CURRENT_DATE, 'Government Portal'),
('Wheat', 2050, 2100, 'Punjab', 'Ludhiana Mandi', CURRENT_DATE, 'Government Portal'),
('Maize', 1650, 1600, 'Karnataka', 'Bangalore Market', CURRENT_DATE, 'Government Portal'),
('Cotton', 5800, 5950, 'Gujarat', 'Rajkot APMC', CURRENT_DATE, 'Government Portal');

-- Insert sample historical data (for ML training)
INSERT INTO historical_harvest_data (
    crop_type, variety, actual_yield, actual_price, area, soil_type, 
    irrigation_type, temperature, humidity, rainfall, location, 
    harvest_date, planting_date, verified
) VALUES
('Rice', 'Basmati', 4.2, 1850, 2.5, 'Clay Loam', 'Drip', 28, 70, 150, 'Maharashtra', '2025-05-15', '2025-01-15', TRUE),
('Wheat', 'HD-2967', 3.8, 2100, 3.0, 'Sandy Loam', 'Sprinkler', 22, 60, 80, 'Punjab', '2025-04-01', '2024-11-01', TRUE),
('Maize', 'Hybrid-123', 5.5, 1600, 1.8, 'Black Soil', 'Drip', 25, 65, 100, 'Karnataka', '2025-06-10', '2025-02-10', TRUE);

-- =============================================================================
-- Grants and Permissions
-- =============================================================================

-- Create application user (optional)
-- CREATE USER smart_harvest_app WITH PASSWORD 'your_secure_password';
-- GRANT CONNECT ON DATABASE smart_harvest TO smart_harvest_app;
-- GRANT USAGE ON SCHEMA public TO smart_harvest_app;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO smart_harvest_app;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO smart_harvest_app;

-- =============================================================================
-- Database Information
-- =============================================================================

-- Show all tables
SELECT 
    table_name,
    (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = t.table_name) as column_count
FROM information_schema.tables t
WHERE table_schema = 'public'
AND table_type = 'BASE TABLE'
ORDER BY table_name;

COMMENT ON DATABASE smart_harvest IS 'Smart Harvest - Agricultural Prediction System Database';
COMMENT ON TABLE users IS 'User accounts for farmers, admins, and experts';
COMMENT ON TABLE crops IS 'Crop information entered by farmers';
COMMENT ON TABLE predictions IS 'ML-generated predictions for yield and price';
COMMENT ON TABLE market_prices IS 'Current and historical market price data';
COMMENT ON TABLE historical_harvest_data IS 'Historical data for ML model training';
