# Smart Harvest Backend - FastAPI Application
# Place this file in: backend/main.py

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime, timedelta
import pickle
import numpy as np
from passlib.context import CryptContext
from jose import JWTError, jwt

# =============================================================================
# Configuration
# =============================================================================

SECRET_KEY = "your-secret-key-change-this-in-production"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

app = FastAPI(
    title="Smart Harvest API",
    description="Harvest and Market Price Prediction API",
    version="1.0.0"
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/login")

# =============================================================================
# Pydantic Models (Request/Response Schemas)
# =============================================================================

class UserRegister(BaseModel):
    name: str
    email: EmailStr
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(BaseModel):
    id: str
    name: str
    email: str
    role: str = "farmer"

class Token(BaseModel):
    access_token: str
    token_type: str

class CropCreate(BaseModel):
    crop_type: str
    variety: str
    planting_date: str
    expected_harvest_date: str
    area: float
    soil_type: str
    irrigation_type: str
    temperature: float
    humidity: float
    rainfall: float
    location: str

class CropResponse(CropCreate):
    id: str
    user_id: str
    created_at: datetime

class PredictionResponse(BaseModel):
    id: str
    crop_id: str
    crop_type: str
    predicted_yield: float
    predicted_price: float
    confidence: float
    timestamp: datetime
    factors: dict

# =============================================================================
# Authentication Utilities
# =============================================================================

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme)) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
        # TODO: Get user from database
        # For now, return mock user
        return User(id="1", name="John Farmer", email=email, role="farmer")
    except JWTError:
        raise credentials_exception

# =============================================================================
# Machine Learning Model Loading
# =============================================================================

# Load models at startup (once dataset is collected and models are trained)
try:
    with open('models/harvest_yield_model.pkl', 'rb') as f:
        yield_model = pickle.load(f)
    with open('models/price_prediction_model.pkl', 'rb') as f:
        price_model = pickle.load(f)
    print("✅ ML Models loaded successfully")
except FileNotFoundError:
    print("⚠️  ML Models not found. Using mock predictions.")
    yield_model = None
    price_model = None

def prepare_features(crop_data: dict) -> np.ndarray:
    """
    Prepare features for ML model prediction.
    Encode categorical variables and normalize numerical features.
    """
    # Example feature preparation
    # TODO: Implement proper encoding based on your trained model
    
    crop_type_map = {"Rice": 0, "Wheat": 1, "Maize": 2, "Cotton": 3}
    soil_type_map = {"Clay Loam": 0, "Sandy Loam": 1, "Silty Clay": 2}
    irrigation_map = {"Drip": 0, "Sprinkler": 1, "Flood": 2, "Rainfed": 3}
    
    features = np.array([[
        crop_type_map.get(crop_data['crop_type'], 0),
        soil_type_map.get(crop_data['soil_type'], 0),
        irrigation_map.get(crop_data['irrigation_type'], 0),
        crop_data['area'],
        crop_data['temperature'],
        crop_data['humidity'],
        crop_data['rainfall']
    ]])
    
    return features

# =============================================================================
# API Endpoints
# =============================================================================

@app.get("/")
async def root():
    return {
        "message": "Smart Harvest API",
        "version": "1.0.0",
        "status": "running"
    }

# -----------------------------------------------------------------------------
# Authentication Endpoints
# -----------------------------------------------------------------------------

@app.post("/api/auth/register", response_model=dict)
async def register(user_data: UserRegister):
    """Register a new user"""
    # TODO: Check if user exists in database
    # TODO: Hash password and save to database
    
    hashed_password = get_password_hash(user_data.password)
    
    # Mock: Create user in database
    new_user = User(
        id="generated-uuid",
        name=user_data.name,
        email=user_data.email,
        role="farmer"
    )
    
    # Create access token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user_data.email}, expires_delta=access_token_expires
    )
    
    return {
        "user": new_user,
        "token": access_token,
        "token_type": "bearer"
    }

@app.post("/api/auth/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    """Login user and return access token"""
    # TODO: Verify user credentials from database
    
    # Mock authentication
    # In production, fetch user from database and verify password
    user = User(
        id="1",
        name="John Farmer",
        email=form_data.username,
        role="farmer"
    )
    
    # Create access token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": user
    }

@app.get("/api/auth/me", response_model=User)
async def get_current_user_info(current_user: User = Depends(get_current_user)):
    """Get current logged-in user information"""
    return current_user

# -----------------------------------------------------------------------------
# Crop Endpoints
# -----------------------------------------------------------------------------

@app.post("/api/crops", response_model=dict)
async def create_crop(
    crop_data: CropCreate,
    current_user: User = Depends(get_current_user)
):
    """Create a new crop entry"""
    # TODO: Save crop to database
    
    crop_dict = crop_data.dict()
    crop_dict.update({
        "id": "generated-crop-id",
        "user_id": current_user.id,
        "created_at": datetime.utcnow()
    })
    
    return crop_dict

@app.get("/api/crops", response_model=List[dict])
async def get_crops(current_user: User = Depends(get_current_user)):
    """Get all crops for current user"""
    # TODO: Fetch crops from database where user_id = current_user.id
    
    # Mock data
    return [
        {
            "id": "1",
            "user_id": current_user.id,
            "crop_type": "Rice",
            "variety": "Basmati",
            "planting_date": "2026-01-15",
            "expected_harvest_date": "2026-05-15",
            "area": 2.5,
            "soil_type": "Clay Loam",
            "irrigation_type": "Drip",
            "temperature": 28,
            "humidity": 70,
            "rainfall": 150,
            "location": "Maharashtra",
            "created_at": datetime.utcnow()
        }
    ]

# -----------------------------------------------------------------------------
# Prediction Endpoints
# -----------------------------------------------------------------------------

@app.post("/api/predictions/{crop_id}", response_model=PredictionResponse)
async def create_prediction(
    crop_id: str,
    current_user: User = Depends(get_current_user)
):
    """Generate prediction for a crop"""
    # TODO: Fetch crop from database
    
    # Mock crop data
    crop = {
        "id": crop_id,
        "crop_type": "Rice",
        "area": 2.5,
        "temperature": 28,
        "humidity": 70,
        "rainfall": 150,
        "soil_type": "Clay Loam",
        "irrigation_type": "Drip"
    }
    
    # Prepare features
    features = prepare_features(crop)
    
    # Make predictions
    if yield_model and price_model:
        predicted_yield = yield_model.predict(features)[0]
        predicted_price = price_model.predict(features)[0]
        confidence = 85.0  # Calculate from model
    else:
        # Mock predictions
        predicted_yield = 4.2
        predicted_price = 1850
        confidence = 87.0
    
    # Calculate factors
    factors = {
        "weather": 85,
        "soil": 90,
        "historical": 86
    }
    
    # TODO: Save prediction to database
    
    return PredictionResponse(
        id="generated-prediction-id",
        crop_id=crop_id,
        crop_type=crop["crop_type"],
        predicted_yield=predicted_yield,
        predicted_price=predicted_price,
        confidence=confidence,
        timestamp=datetime.utcnow(),
        factors=factors
    )

@app.get("/api/predictions", response_model=List[PredictionResponse])
async def get_predictions(current_user: User = Depends(get_current_user)):
    """Get all predictions for current user"""
    # TODO: Fetch predictions from database with JOIN on crops table
    
    return []

# -----------------------------------------------------------------------------
# Market Price Endpoints
# -----------------------------------------------------------------------------

@app.get("/api/market-prices")
async def get_market_prices():
    """Get current market prices"""
    # TODO: Fetch from database or external API
    
    return [
        {
            "id": "1",
            "crop_type": "Rice",
            "current_price": 1820,
            "previous_price": 1750,
            "change": 4.0,
            "location": "Maharashtra",
            "last_updated": datetime.utcnow()
        }
    ]

@app.get("/api/market-prices/{crop_type}/history")
async def get_price_history(crop_type: str, days: int = 30):
    """Get historical price data for a crop"""
    # TODO: Fetch from database
    
    history = []
    base_price = 1800
    
    for i in range(days):
        date = datetime.utcnow() - timedelta(days=days-i)
        variation = np.random.randint(-100, 100)
        history.append({
            "date": date.strftime("%Y-%m-%d"),
            "price": base_price + variation
        })
    
    return history

# -----------------------------------------------------------------------------
# Dashboard Endpoints
# -----------------------------------------------------------------------------

@app.get("/api/dashboard/stats")
async def get_dashboard_stats(current_user: User = Depends(get_current_user)):
    """Get dashboard statistics"""
    # TODO: Calculate from database
    
    return {
        "total_crops": 2,
        "active_predictions": 2,
        "average_yield": 4.0,
        "total_revenue": 125000,
        "recent_activity": [
            {
                "type": "prediction",
                "message": "New prediction generated for Rice crop",
                "time": "2 hours ago"
            }
        ]
    }

# =============================================================================
# Startup and Shutdown Events
# =============================================================================

@app.on_event("startup")
async def startup_event():
    """Initialize services on startup"""
    print("🚀 Smart Harvest API starting...")
    # TODO: Initialize database connection
    # TODO: Load ML models
    # TODO: Start background tasks (price updates, etc.)

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    print("👋 Smart Harvest API shutting down...")
    # TODO: Close database connections
    # TODO: Save any pending data

# =============================================================================
# Run Application
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)

"""
To run this application:

1. Install dependencies:
   pip install -r backend-requirements.txt

2. Run the server:
   python main.py
   
   OR
   
   uvicorn main:app --reload

3. Access API documentation:
   - Swagger UI: http://localhost:8000/docs
   - ReDoc: http://localhost:8000/redoc

4. Test endpoints:
   curl http://localhost:8000/
"""
