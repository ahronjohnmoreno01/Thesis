# Smart Harvest - Backend Integration Guide

## Overview
This document explains how to integrate the Smart Harvest frontend with a Python backend and machine learning models.

## Backend Architecture

### Technology Stack
- **Framework**: FastAPI or Flask
- **Database**: PostgreSQL or MySQL
- **ML Libraries**: scikit-learn, TensorFlow, or PyTorch
- **API**: RESTful endpoints

---

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'farmer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Crops Table
```sql
CREATE TABLE crops (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    crop_type VARCHAR(100) NOT NULL,
    variety VARCHAR(100) NOT NULL,
    planting_date DATE NOT NULL,
    expected_harvest_date DATE NOT NULL,
    area DECIMAL(10, 2) NOT NULL,
    soil_type VARCHAR(100) NOT NULL,
    irrigation_type VARCHAR(100) NOT NULL,
    temperature DECIMAL(5, 2),
    humidity DECIMAL(5, 2),
    rainfall DECIMAL(7, 2),
    location VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Predictions Table
```sql
CREATE TABLE predictions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    crop_id UUID REFERENCES crops(id),
    predicted_yield DECIMAL(10, 2) NOT NULL,
    predicted_price DECIMAL(10, 2) NOT NULL,
    confidence DECIMAL(5, 2) NOT NULL,
    weather_factor DECIMAL(5, 2),
    soil_factor DECIMAL(5, 2),
    historical_factor DECIMAL(5, 2),
    model_version VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Market Prices Table
```sql
CREATE TABLE market_prices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    crop_type VARCHAR(100) NOT NULL,
    current_price DECIMAL(10, 2) NOT NULL,
    previous_price DECIMAL(10, 2),
    location VARCHAR(255) NOT NULL,
    price_date DATE NOT NULL,
    source VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_market_prices_crop_date ON market_prices(crop_type, price_date);
```

### Historical Data Table
```sql
CREATE TABLE historical_harvest_data (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    crop_type VARCHAR(100) NOT NULL,
    variety VARCHAR(100),
    actual_yield DECIMAL(10, 2) NOT NULL,
    actual_price DECIMAL(10, 2),
    area DECIMAL(10, 2),
    soil_type VARCHAR(100),
    temperature DECIMAL(5, 2),
    humidity DECIMAL(5, 2),
    rainfall DECIMAL(7, 2),
    location VARCHAR(255),
    harvest_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## Backend API Endpoints

### Authentication Endpoints

**POST /api/auth/register**
```python
@app.post("/api/auth/register")
async def register(user: UserRegister):
    # Hash password
    password_hash = hash_password(user.password)
    
    # Insert into database
    new_user = db.execute(
        "INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING *",
        user.name, user.email, password_hash
    )
    
    # Generate JWT token
    token = generate_jwt_token(new_user.id)
    return {"user": new_user, "token": token}
```

**POST /api/auth/login**
```python
@app.post("/api/auth/login")
async def login(credentials: LoginRequest):
    user = db.execute(
        "SELECT * FROM users WHERE email = $1",
        credentials.email
    )
    
    if not user or not verify_password(credentials.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = generate_jwt_token(user.id)
    return {"user": user, "token": token}
```

### Crop Data Endpoints

**POST /api/crops**
```python
@app.post("/api/crops")
async def create_crop(crop: CropCreate, current_user: User = Depends(get_current_user)):
    new_crop = db.execute(
        """INSERT INTO crops (
            user_id, crop_type, variety, planting_date, expected_harvest_date,
            area, soil_type, irrigation_type, temperature, humidity, rainfall, location
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING *""",
        current_user.id, crop.crop_type, crop.variety, crop.planting_date,
        crop.expected_harvest_date, crop.area, crop.soil_type, crop.irrigation_type,
        crop.temperature, crop.humidity, crop.rainfall, crop.location
    )
    return new_crop
```

**GET /api/crops**
```python
@app.get("/api/crops")
async def get_crops(current_user: User = Depends(get_current_user)):
    crops = db.execute(
        "SELECT * FROM crops WHERE user_id = $1 ORDER BY created_at DESC",
        current_user.id
    )
    return crops
```

### Prediction Endpoints

**POST /api/predictions/{crop_id}**
```python
import pickle
import numpy as np

# Load trained model (do this once at startup)
with open('models/harvest_yield_model.pkl', 'rb') as f:
    yield_model = pickle.load(f)

with open('models/price_prediction_model.pkl', 'rb') as f:
    price_model = pickle.load(f)

@app.post("/api/predictions/{crop_id}")
async def create_prediction(crop_id: str, current_user: User = Depends(get_current_user)):
    # Get crop data
    crop = db.execute("SELECT * FROM crops WHERE id = $1 AND user_id = $2", crop_id, current_user.id)
    if not crop:
        raise HTTPException(status_code=404, detail="Crop not found")
    
    # Prepare features for ML model
    features = prepare_features(crop)
    
    # Make predictions using trained models
    predicted_yield = yield_model.predict(features)[0]
    predicted_price = price_model.predict(features)[0]
    
    # Get prediction confidence/probability
    if hasattr(yield_model, 'predict_proba'):
        confidence = yield_model.predict_proba(features).max() * 100
    else:
        confidence = 85.0  # Default confidence
    
    # Calculate factor contributions
    weather_factor = calculate_weather_impact(crop)
    soil_factor = calculate_soil_impact(crop)
    historical_factor = get_historical_factor(crop.crop_type, crop.location)
    
    # Save prediction to database
    prediction = db.execute(
        """INSERT INTO predictions (
            crop_id, predicted_yield, predicted_price, confidence,
            weather_factor, soil_factor, historical_factor, model_version
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *""",
        crop_id, predicted_yield, predicted_price, confidence,
        weather_factor, soil_factor, historical_factor, "v1.0"
    )
    
    return prediction

def prepare_features(crop):
    """Prepare features for ML model"""
    # Encode categorical variables
    crop_encoding = encode_crop_type(crop.crop_type)
    soil_encoding = encode_soil_type(crop.soil_type)
    irrigation_encoding = encode_irrigation_type(crop.irrigation_type)
    location_encoding = encode_location(crop.location)
    
    # Calculate derived features
    days_to_harvest = (crop.expected_harvest_date - crop.planting_date).days
    
    # Combine all features
    features = np.array([[
        crop_encoding,
        soil_encoding,
        irrigation_encoding,
        location_encoding,
        crop.area,
        crop.temperature,
        crop.humidity,
        crop.rainfall,
        days_to_harvest
    ]])
    
    return features
```

**GET /api/predictions**
```python
@app.get("/api/predictions")
async def get_predictions(current_user: User = Depends(get_current_user)):
    predictions = db.execute(
        """SELECT p.*, c.crop_type, c.variety, c.location
           FROM predictions p
           JOIN crops c ON p.crop_id = c.id
           WHERE c.user_id = $1
           ORDER BY p.created_at DESC""",
        current_user.id
    )
    return predictions
```

### Market Price Endpoints

**GET /api/market-prices**
```python
@app.get("/api/market-prices")
async def get_market_prices():
    # Get latest prices for each crop type
    prices = db.execute(
        """SELECT DISTINCT ON (crop_type, location)
           crop_type, current_price, previous_price, location, price_date
           FROM market_prices
           ORDER BY crop_type, location, price_date DESC"""
    )
    
    # Calculate price changes
    result = []
    for price in prices:
        change = ((price.current_price - price.previous_price) / price.previous_price * 100) if price.previous_price else 0
        result.append({
            **price,
            "change": round(change, 2),
            "last_updated": price.price_date
        })
    
    return result
```

**GET /api/market-prices/{crop_type}/history**
```python
@app.get("/api/market-prices/{crop_type}/history")
async def get_price_history(crop_type: str, days: int = 30):
    from_date = datetime.now() - timedelta(days=days)
    
    history = db.execute(
        """SELECT price_date as date, AVG(current_price) as price
           FROM market_prices
           WHERE crop_type = $1 AND price_date >= $2
           GROUP BY price_date
           ORDER BY price_date ASC""",
        crop_type, from_date
    )
    
    return history
```

### Dashboard Statistics Endpoint

**GET /api/dashboard/stats**
```python
@app.get("/api/dashboard/stats")
async def get_dashboard_stats(current_user: User = Depends(get_current_user)):
    total_crops = db.execute(
        "SELECT COUNT(*) FROM crops WHERE user_id = $1",
        current_user.id
    )[0]
    
    active_predictions = db.execute(
        """SELECT COUNT(*) FROM predictions p
           JOIN crops c ON p.crop_id = c.id
           WHERE c.user_id = $1""",
        current_user.id
    )[0]
    
    avg_yield = db.execute(
        """SELECT AVG(predicted_yield) FROM predictions p
           JOIN crops c ON p.crop_id = c.id
           WHERE c.user_id = $1""",
        current_user.id
    )[0] or 0
    
    total_revenue = db.execute(
        """SELECT SUM(p.predicted_yield * c.area * p.predicted_price / 100)
           FROM predictions p
           JOIN crops c ON p.crop_id = c.id
           WHERE c.user_id = $1""",
        current_user.id
    )[0] or 0
    
    recent_activity = db.execute(
        """(SELECT 'prediction' as type, 'New prediction generated' as message, 
                  created_at as time FROM predictions p
                  JOIN crops c ON p.crop_id = c.id WHERE c.user_id = $1)
           UNION ALL
           (SELECT 'crop' as type, 'New crop added' as message, 
                  created_at as time FROM crops WHERE user_id = $1)
           ORDER BY time DESC LIMIT 10""",
        current_user.id
    )
    
    return {
        "total_crops": total_crops,
        "active_predictions": active_predictions,
        "average_yield": round(avg_yield, 2),
        "total_revenue": round(total_revenue, 2),
        "recent_activity": recent_activity
    }
```

---

## Machine Learning Model Integration

### Model Training Pipeline

```python
# train_model.py
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
import pickle

def train_yield_prediction_model(data_path):
    # Load historical data
    df = pd.read_csv(data_path)
    
    # Feature engineering
    X = df[['crop_type_encoded', 'soil_type_encoded', 'irrigation_encoded',
            'location_encoded', 'area', 'temperature', 'humidity', 
            'rainfall', 'days_to_harvest']]
    y = df['actual_yield']
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train model
    model = RandomForestRegressor(
        n_estimators=100,
        max_depth=20,
        random_state=42
    )
    model.fit(X_train_scaled, y_train)
    
    # Evaluate
    score = model.score(X_test_scaled, y_test)
    print(f"Model R² Score: {score}")
    
    # Save model and scaler
    with open('models/harvest_yield_model.pkl', 'wb') as f:
        pickle.dump(model, f)
    with open('models/yield_scaler.pkl', 'wb') as f:
        pickle.dump(scaler, f)
    
    return model

def train_price_prediction_model(data_path):
    # Similar process for price prediction
    # ... implementation
    pass
```

### Using TensorFlow/Keras Models

```python
# For .h5 models
from tensorflow.keras.models import load_model

# Load model at startup
yield_model = load_model('models/harvest_model.h5')

@app.post("/api/predictions/{crop_id}")
async def create_prediction_tf(crop_id: str):
    crop = get_crop_from_db(crop_id)
    features = prepare_features_for_tf(crop)
    
    # Reshape for TensorFlow
    features = features.reshape(1, -1)
    
    # Make prediction
    predicted_yield = yield_model.predict(features)[0][0]
    
    return {"predicted_yield": float(predicted_yield)}
```

---

## Frontend API Integration

Update `/src/app/services/api.ts` to connect to backend:

```typescript
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

// Add authentication token to requests
const getAuthHeader = () => {
  const token = localStorage.getItem('auth_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

export const cropService = {
  async submitCropData(cropData: CropData): Promise<CropData> {
    const response = await fetch(`${API_BASE_URL}/crops`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader()
      },
      body: JSON.stringify(cropData)
    });
    
    if (!response.ok) throw new Error('Failed to submit crop data');
    return response.json();
  }
};
```

---

## Deployment Instructions

### Local Development

1. **Backend Setup**:
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

2. **Database Setup**:
```bash
psql -U postgres
CREATE DATABASE smart_harvest;
\c smart_harvest
\i schema.sql
```

3. **Frontend Setup** (already running in Figma Make)

### Docker Deployment

```yaml
# docker-compose.yml
version: '3.8'

services:
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: smart_harvest
      POSTGRES_PASSWORD: your_password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      DATABASE_URL: postgresql://postgres:your_password@db/smart_harvest
    depends_on:
      - db

  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      REACT_APP_API_URL: http://localhost:8000/api

volumes:
  postgres_data:
```

### Cloud Deployment Options

1. **Backend**: Deploy to AWS Lambda, Google Cloud Run, or Heroku
2. **Database**: Use AWS RDS, Google Cloud SQL, or Supabase
3. **Frontend**: Deploy to Vercel, Netlify, or AWS Amplify

---

## Data Collection & Model Training

### Dataset Requirements

Your dataset should include:
- Crop type and variety
- Soil characteristics
- Weather data (temperature, humidity, rainfall)
- Irrigation methods
- Planting and harvest dates
- Actual yield (tons/hectare)
- Market prices at harvest time

### Recommended Format

```csv
crop_type,variety,soil_type,irrigation,area,temperature,humidity,rainfall,days_growth,actual_yield,harvest_price,location
Rice,Basmati,Clay Loam,Drip,2.5,28,70,150,120,4.2,1850,Maharashtra
Wheat,HD-2967,Sandy Loam,Sprinkler,3.0,22,60,80,150,3.8,2100,Punjab
```

### Model Retraining Pipeline

Set up a scheduled job to retrain models as new data comes in:

```python
# retrain_schedule.py
from apscheduler.schedulers.background import BackgroundScheduler

scheduler = BackgroundScheduler()

@scheduler.scheduled_job('cron', day_of_week='sun', hour=2)
def weekly_retrain():
    # Fetch new historical data
    new_data = fetch_latest_harvest_data()
    
    # Retrain models
    train_yield_prediction_model('data/updated_dataset.csv')
    train_price_prediction_model('data/updated_dataset.csv')
    
    # Update model version in database
    update_model_version('v2.0', datetime.now())

scheduler.start()
```

---

## Security Considerations

1. **Authentication**: Use JWT tokens with secure secrets
2. **Password Hashing**: Use bcrypt or argon2
3. **API Rate Limiting**: Implement rate limiting on endpoints
4. **Input Validation**: Validate all inputs on backend
5. **CORS**: Configure proper CORS policies
6. **Environment Variables**: Never commit secrets to git

---

## API Documentation

Generate API documentation using FastAPI's built-in Swagger:
- Access at: `http://localhost:8000/docs`
- ReDoc at: `http://localhost:8000/redoc`
