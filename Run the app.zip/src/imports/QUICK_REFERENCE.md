# 🚀 Smart Harvest - Quick Reference Card

## Demo Access
- **URL**: Currently running in Figma Make
- **Email**: demo@farmer.com
- **Password**: demo123

## Application Routes
```
/                    → Login Page
/register            → Registration Page
/dashboard           → Dashboard (main hub)
/crop-input          → Add Crop Form
/predictions         → Predictions & Results
/market-prices       → Market Analysis & Charts
```

## Key Features by Page

### 🔐 Login/Register
- Email & password authentication
- Form validation
- Session management
- Demo credentials provided

### 📊 Dashboard
- 4 statistics cards (crops, predictions, yield, revenue)
- Recent crops (last 3)
- Market price summary (4 crops)
- Activity feed
- Quick action buttons

### 🌱 Crop Input
- **Crop Info**: Type, variety, dates, area, location
- **Soil & Irrigation**: Soil type, irrigation method
- **Environment**: Temperature, humidity, rainfall
- Auto-navigation to predictions after submit

### 🤖 Predictions
- Generate predictions for any crop
- Yield prediction (tons)
- Price prediction (₹/quintal)
- Confidence score (%)
- Factor breakdown (weather, soil, historical)
- Revenue estimation
- Visual progress bars

### 📈 Market Prices
- 4 crop price cards (interactive)
- 30-day price history chart
- Table view option
- Price trend indicators (+/- %)
- Market insights panel
- Refresh functionality

## Tech Stack

### Frontend
- React 18.3.1 + TypeScript
- React Router 7 (Data API)
- Tailwind CSS 4
- Recharts (charts)
- Radix UI (components)
- Lucide React (icons)
- Sonner (toasts)

### Backend (To Implement)
- Python 3.10+
- FastAPI
- PostgreSQL 14+
- SQLAlchemy
- JWT Authentication

### ML (To Implement)
- scikit-learn
- TensorFlow/PyTorch
- NumPy/Pandas

## File Structure
```
/src/app/
├── App.tsx                    # Main app
├── routes.ts                  # Router config
├── /pages/                    # 7 page components
├── /services/api.ts           # API layer
└── /components/               # UI components
```

## Documentation Files
```
/src/imports/
├── README.md                      # Overview
├── PROJECT_STRUCTURE.md           # Architecture
├── BACKEND_INTEGRATION.md         # Backend guide
├── IMPLEMENTATION_GUIDE.md        # Step-by-step
├── backend-requirements.txt       # Python deps
├── backend-main.py                # Sample API
└── database-schema.sql            # SQL schema
```

## API Service Methods

### Authentication
```typescript
authService.login(email, password)
authService.register(name, email, password)
authService.getCurrentUser()
authService.logout()
```

### Crops
```typescript
cropService.submitCropData(cropData)
cropService.getCrops()
```

### Predictions
```typescript
predictionService.getPrediction(cropId)
predictionService.getAllPredictions()
```

### Market
```typescript
marketService.getMarketPrices()
marketService.getPriceHistory(cropType)
```

### Dashboard
```typescript
dashboardService.getStatistics()
```

## Mock Data Available

### Crops
- 2 sample crops (Rice, Wheat)
- Full environmental data
- Location: Maharashtra, Punjab

### Predictions
- 2 sample predictions
- Confidence: 82-87%
- Factors breakdown

### Market Prices
- 4 crops (Rice, Wheat, Maize, Cotton)
- Current prices (₹1600-5800)
- Price changes (-2.5% to +4%)
- 30-day history

## Common Tasks

### Add New Crop
1. Dashboard → "Add New Crop" button
2. Fill all form sections
3. Submit → Auto-navigate to predictions

### Generate Prediction
1. Predictions page → "Generate New Predictions"
2. Click "Generate Prediction" on any crop
3. View results with confidence scores

### Analyze Market
1. Market Prices page
2. Click any crop card to view history
3. Toggle between Chart/Table view

## Environment Setup (Future)

### Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

### Database
```bash
createdb smart_harvest
psql -d smart_harvest -f database-schema.sql
```

### Environment Variables
```
DATABASE_URL=postgresql://user:pass@localhost/smart_harvest
SECRET_KEY=your-secret-key
```

## Model Training (Future)

```python
# Prepare data
X = features[['crop_type', 'soil', 'temp', 'humidity', 'rainfall']]
y = target['actual_yield']

# Train
model = RandomForestRegressor(n_estimators=100)
model.fit(X_train, y_train)

# Save
pickle.dump(model, open('harvest_model.pkl', 'wb'))
```

## Deployment Checklist

- [ ] Backend: AWS/GCP/Heroku
- [ ] Database: RDS/Cloud SQL
- [ ] Frontend: Vercel/Netlify
- [ ] ML Models: Load on backend startup
- [ ] Environment variables configured
- [ ] HTTPS enabled
- [ ] CORS configured

## Key Components

### UI Components (40+)
- Button, Card, Input, Label
- Select, Tabs, Badge, Progress
- Dialog, Sheet, Dropdown
- Table, Chart, Form
- And many more...

### Page Components (7)
- Root (layout + nav)
- Login, Register
- Dashboard
- CropInput
- PredictionResults
- MarketPrices

## Responsive Breakpoints
- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

## Color Theme
- Primary: Green (agriculture)
- Secondary: Blue (data/tech)
- Accent: Purple, Yellow
- Neutral: Gray scale

## Browser Support
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Performance
- Initial load: < 2s
- Route transitions: Instant
- Chart rendering: < 500ms
- API calls: Mock (instant)

## Security (Production)
- JWT authentication
- Bcrypt password hashing
- HTTPS only
- Input sanitization
- CSRF protection
- Rate limiting

## Testing Strategy
- Unit: Jest + RTL
- Integration: Supertest
- E2E: Cypress/Playwright
- Backend: Pytest
- ML: Model accuracy tests

## Support & Help

### Documentation
- Read `/src/imports/*.md` files
- Check code comments
- Review API service layer

### Common Issues
- CORS: Configure in backend
- Auth: Check token storage
- DB: Verify connection string
- Model: Check file paths

## Next Steps (Priority Order)

1. **Backend Setup** (Week 1-2)
   - Install dependencies
   - Create FastAPI app
   - Set up PostgreSQL
   - Test endpoints

2. **Data Collection** (Ongoing)
   - Government sources
   - Weather APIs
   - Farmer surveys
   - Historical records

3. **ML Training** (Week 3-4)
   - Preprocess data
   - Train models
   - Evaluate accuracy
   - Save models

4. **Integration** (Week 5)
   - Connect frontend to backend
   - Test all flows
   - Deploy to staging

5. **Deployment** (Week 6)
   - Production deployment
   - Performance testing
   - Documentation finalization

## Success Metrics

### Technical
- API response < 200ms
- Model accuracy > 80%
- Zero security vulnerabilities
- 100% mobile responsive

### User Experience
- Intuitive navigation
- Clear feedback
- Fast load times
- Accessible (WCAG 2.1)

### Academic
- Complete implementation
- Proper documentation
- Working demo
- Research contribution

---

**Status**: ✅ Frontend Complete | ⏳ Backend Pending | ⏳ ML Pending

**Version**: 1.0.0  
**Last Updated**: March 3, 2026  
**Platform**: Figma Make (React + TypeScript)

---

💡 **Pro Tip**: Start with backend setup while collecting data for ML training!
