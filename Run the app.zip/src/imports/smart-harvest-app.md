Develop a complete, implementation-ready mobile application prototype for a thesis project titled “Smart Harvest and Market Price Prediction System using Machine Learning.”

The dataset is still under collection; therefore, design the system using a modular and scalable architecture that supports future dataset integration and machine learning model deployment. Use mock or placeholder data where necessary, but structure the system for seamless future model integration.

Provide the following with actual source code and clear explanations:

Frontend (Mobile App) Source Code

Use Flutter (recommended) or React Native.

Include screens for:

User login/registration

Crop data input form

Prediction results display

Market price comparison

Dashboard overview

Backend Source Code

Use Python (FastAPI or Flask).

Include RESTful API endpoints for:

User management

Data submission

Prediction request

Market price retrieval

Include a placeholder machine learning prediction function ready for future model loading.

Database Schema Design with SQL Code

Tables for users, crops, market prices, predictions, and historical data.

Ensure normalization and scalability for future dataset expansion.

Machine Learning Integration Structure

Provide sample code showing how a trained model (.pkl or .h5 file) will be loaded and used for prediction in the backend.

Use a mock prediction function for now.

Project Folder Structure

Clearly define frontend, backend, database, and ML directories.

Deployment Setup

Instructions for running locally (Docker optional).

Ready for future cloud deployment.