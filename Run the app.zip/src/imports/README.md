# 🌾 Smart Harvest - Harvest & Market Price Prediction System

A complete, production-ready web application for predicting harvest yields and market prices using machine learning. Built for thesis project with modular, scalable architecture ready for ML model integration.

![Status](https://img.shields.io/badge/Status-Frontend%20Complete-success)
![Tech](https://img.shields.io/badge/Tech-React%20%7C%20TypeScript%20%7C%20Python-blue)
![License](https://img.shields.io/badge/License-Academic-orange)

---

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Screenshots](#screenshots)
- [Technology Stack](#technology-stack)
- [Getting Started](#getting-started)
- [Project Structure](#project-structure)
- [Backend Integration](#backend-integration)
- [Machine Learning](#machine-learning)
- [Deployment](#deployment)
- [Documentation](#documentation)

---

## 🎯 Overview

Smart Harvest is a comprehensive agricultural technology solution that helps farmers make data-driven decisions by:
- **Predicting harvest yields** based on environmental and crop data
- **Forecasting market prices** to optimize selling strategies
- **Analyzing market trends** across different crops and regions
- **Tracking crop performance** with historical data

### Thesis Context
**Title**: "Smart Harvest and Market Price Prediction System using Machine Learning"

**Objectives**:
1. Develop user-friendly web application for farmers
2. Integrate ML models for yield and price prediction
3. Provide real-time market intelligence
4. Demonstrate scalable cloud-ready architecture

---

## ✨ Features

### 🔐 Authentication System
- Secure login and registration
- User session management
- Demo credentials for testing

### 📊 Dashboard
- Real-time statistics overview
- Total crops, predictions, revenue tracking
- Recent activity feed
- Quick action buttons
- Market price summaries

### 🌱 Crop Data Management
- Comprehensive crop information form
- Environmental condition tracking
- Soil and irrigation parameters
- Location-based data entry

### 🤖 AI-Powered Predictions
- Machine learning yield predictions
- Market price forecasting
- Confidence scores with factor analysis
- Revenue estimation
- Historical prediction tracking

### 📈 Market Analysis
- Real-time market prices
- Interactive 30-day price charts
- Price trend indicators
- Location-based pricing
- Market insights and analytics

### 📱 Responsive Design
- Mobile-optimized interface
- Touch-friendly controls
- Adaptive layouts
- Progressive web app ready

---

## 🖼️ Screenshots

### Login Page
Clean, intuitive login interface with demo credentials

### Dashboard
Comprehensive overview with statistics, recent crops, and market prices

### Crop Input Form
Detailed form for entering crop and environmental data

### Predictions
AI-generated predictions with confidence factors and revenue estimates

### Market Prices
Interactive charts and real-time market data analysis

---

## 🛠️ Technology Stack

### Frontend
- **React 18.3.1** - Modern UI library
- **TypeScript** - Type-safe JavaScript
- **React Router 7** - Client-side routing
- **Tailwind CSS 4** - Utility-first styling
- **Recharts** - Data visualization
- **Radix UI** - Accessible components
- **Vite** - Fast build tool

### Backend (Ready for Integration)
- **FastAPI** - Modern Python API framework
- **PostgreSQL** - Relational database
- **SQLAlchemy** - ORM for database operations
- **JWT** - Token-based authentication

### Machine Learning
- **scikit-learn** - Classical ML algorithms
- **TensorFlow/Keras** - Deep learning models
- **PyTorch** - Alternative DL framework
- **NumPy/Pandas** - Data processing

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ (for frontend development)
- Python 3.10+ (for backend)
- PostgreSQL 14+ (for database)

### Quick Start (Frontend)

The application is currently running in Figma Make. To access:

1. **Navigate to Login** - Use demo credentials:
   - Email: `demo@farmer.com`
   - Password: `demo123`

2. **Explore Features**:
   - Dashboard → View overview
   - Add Crop → Enter crop data
   - Predictions → Generate predictions
   - Market Prices → Analyze trends

### Local Development Setup

#### Frontend
```bash
# Already set up in Figma Make
# For local development outside Figma:
npm install
npm run dev
```

#### Backend Setup (Future)
```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r backend-requirements.txt

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Run database migrations
alembic upgrade head

# Start server
uvicorn main:app --reload
```

#### Database Setup
```bash
# Create database
psql -U postgres
CREATE DATABASE smart_harvest;

# Run schema
\c smart_harvest
\i database/schema.sql
```

---

## 📂 Project Structure

```
smart-harvest/
├── src/
│   ├── app/
│   │   ├── App.tsx                    # Main entry point
│   │   ├── routes.ts                  # Routing configuration
│   │   ├── components/                # UI components
│   │   ├── pages/                     # Page components
│   │   │   ├── Login.tsx
│   │   │   ├── Register.tsx
│   │   │   ├── Dashboard.tsx
│   │   │   ├── CropInput.tsx
│   │   │   ├── PredictionResults.tsx
│   │   │   └── MarketPrices.tsx
│   │   └── services/
│   │       └── api.ts                 # API service layer
│   └── styles/                        # Global styles
│
├── backend/ (to be implemented)
│   ├── main.py                        # FastAPI application
│   ├── models/                        # Database models
│   ├── routers/                       # API endpoints
│   ├── services/                      # Business logic
│   ├── ml/                            # ML model integration
│   └── database/                      # Database configuration
│
├── models/ (to be implemented)
│   ├── harvest_yield_model.pkl        # Trained yield model
│   ├── price_prediction_model.pkl     # Trained price model
│   └── training/                      # Model training scripts
│
└── docs/
    ├── PROJECT_STRUCTURE.md           # Detailed structure
    ├── BACKEND_INTEGRATION.md         # Backend guide
    └── backend-requirements.txt       # Python dependencies
```

---

## 🔌 Backend Integration

### API Endpoints Structure

```
Authentication:
POST   /api/auth/register      - User registration
POST   /api/auth/login         - User login
GET    /api/auth/me            - Get current user

Crops:
POST   /api/crops              - Create crop
GET    /api/crops              - Get user's crops
GET    /api/crops/{id}         - Get specific crop
PUT    /api/crops/{id}         - Update crop
DELETE /api/crops/{id}         - Delete crop

Predictions:
POST   /api/predictions/{crop_id}  - Generate prediction
GET    /api/predictions            - Get all predictions
GET    /api/predictions/{id}       - Get specific prediction

Market Prices:
GET    /api/market-prices                    - Get current prices
GET    /api/market-prices/{crop_type}/history - Get price history

Dashboard:
GET    /api/dashboard/stats    - Get statistics
```

### Database Schema

See `BACKEND_INTEGRATION.md` for complete SQL schemas:
- `users` - User accounts
- `crops` - Crop data
- `predictions` - ML predictions
- `market_prices` - Market price data
- `historical_harvest_data` - Training data

### Connecting Frontend to Backend

Update `/src/app/services/api.ts`:

```typescript
const API_BASE_URL = 'http://localhost:8000/api';

export const cropService = {
  async submitCropData(cropData: CropData): Promise<CropData> {
    const response = await fetch(`${API_BASE_URL}/crops`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${getAuthToken()}`
      },
      body: JSON.stringify(cropData)
    });
    return response.json();
  }
};
```

---

## 🤖 Machine Learning Integration

### Dataset Requirements

Your dataset should include:
- **Crop Information**: Type, variety, planting/harvest dates
- **Environmental Data**: Temperature, humidity, rainfall
- **Soil Data**: Type, quality indicators
- **Irrigation**: Method and frequency
- **Actual Outcomes**: Harvest yield, market price

### Model Training Example

```python
# train_model.py
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import pickle

# Load data
df = pd.read_csv('historical_data.csv')

# Prepare features
X = df[['crop_type_encoded', 'soil_type', 'temperature', 
        'humidity', 'rainfall', 'area']]
y = df['actual_yield']

# Split and train
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
model = RandomForestRegressor(n_estimators=100)
model.fit(X_train, y_train)

# Save model
with open('models/harvest_yield_model.pkl', 'wb') as f:
    pickle.dump(model, f)

print(f"Model R² Score: {model.score(X_test, y_test)}")
```

### Backend Integration

```python
# backend/ml/prediction.py
import pickle
import numpy as np

# Load model at startup
with open('models/harvest_yield_model.pkl', 'rb') as f:
    yield_model = pickle.load(f)

def predict_yield(crop_data):
    features = prepare_features(crop_data)
    prediction = yield_model.predict([features])[0]
    confidence = calculate_confidence(features)
    return {
        'predicted_yield': prediction,
        'confidence': confidence
    }
```

---

## 🌐 Deployment

### Option 1: Docker Compose

```yaml
version: '3.8'
services:
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: smart_harvest
  
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    depends_on:
      - db
  
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
```

Run: `docker-compose up`

### Option 2: Cloud Services

**Frontend**:
- Vercel (Recommended)
- Netlify
- AWS Amplify

**Backend**:
- AWS EC2 / Lambda
- Google Cloud Run
- Heroku

**Database**:
- AWS RDS
- Google Cloud SQL
- Supabase

### Environment Variables

```bash
# Backend .env
DATABASE_URL=postgresql://user:pass@localhost/smart_harvest
SECRET_KEY=your-secret-key-here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Frontend .env
REACT_APP_API_URL=http://localhost:8000/api
```

---

## 📚 Documentation

Comprehensive documentation available in:

1. **PROJECT_STRUCTURE.md** - Complete file structure and component details
2. **BACKEND_INTEGRATION.md** - Backend API specs, database schemas, ML integration
3. **backend-requirements.txt** - Python dependencies

### Key Documentation Sections

- Architecture overview
- API endpoint specifications
- Database schema designs
- ML model integration guide
- Deployment instructions
- Security best practices
- Testing strategies

---

## 🧪 Testing

### Recommended Testing Strategy

1. **Unit Tests**: Test individual components and functions
2. **Integration Tests**: Test API endpoints and database operations
3. **E2E Tests**: Test complete user workflows
4. **ML Model Tests**: Validate prediction accuracy

### Example Tests

```typescript
// Frontend test
import { render, screen } from '@testing-library/react';
import { Dashboard } from './pages/Dashboard';

test('renders dashboard statistics', () => {
  render(<Dashboard />);
  expect(screen.getByText(/Total Crops/i)).toBeInTheDocument();
});
```

```python
# Backend test
def test_create_prediction(client, auth_token):
    response = client.post(
        "/api/predictions/crop-123",
        headers={"Authorization": f"Bearer {auth_token}"}
    )
    assert response.status_code == 200
    assert "predicted_yield" in response.json()
```

---

## 🤝 Contributing

This is an academic thesis project. For collaboration:

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

---

## 📝 Thesis Guidelines

### Documentation Tips for Academic Submission

1. **Introduction**: Explain the problem farmers face
2. **Literature Review**: Compare with existing solutions
3. **Methodology**: Describe ML algorithms and architecture
4. **Implementation**: Show code snippets and diagrams
5. **Results**: Present prediction accuracy and user testing
6. **Conclusion**: Discuss impact and future work

### Suggested Diagrams

- System Architecture Diagram
- Data Flow Diagram
- ER Diagram (Database)
- ML Pipeline Flowchart
- User Journey Map

### Screenshots to Include

- All major pages (Login, Dashboard, Forms, Results)
- Mobile responsive views
- Charts and visualizations
- Admin/user interface differences

---

## 🔒 Security

- JWT-based authentication
- Bcrypt password hashing
- HTTPS in production
- Input validation and sanitization
- SQL injection prevention (parameterized queries)
- CORS configuration
- Rate limiting

---

## 📈 Future Enhancements

- [ ] Weather API integration
- [ ] Satellite imagery analysis
- [ ] Mobile app (React Native)
- [ ] Multi-language support
- [ ] Community features (farmer forums)
- [ ] Export reports (PDF)
- [ ] SMS/Email notifications
- [ ] Government scheme integration

---

## 🙏 Acknowledgments

- React and TypeScript communities
- Tailwind CSS team
- FastAPI framework
- scikit-learn developers
- Open source contributors

---

## 📞 Support

For questions or issues related to this thesis project:
- Review the documentation files
- Check `BACKEND_INTEGRATION.md` for technical details
- Refer to `PROJECT_STRUCTURE.md` for architecture

---

## 📄 License

This project is developed for academic purposes as part of a thesis submission.

---

**Project Status**: ✅ Frontend Complete | ⏳ Backend Ready for Integration | ⏳ ML Models Pending Data Collection

**Version**: 1.0.0  
**Last Updated**: March 3, 2026  
**Developer**: Thesis Project  
**Tech Stack**: React + TypeScript + Python + FastAPI + PostgreSQL + scikit-learn
