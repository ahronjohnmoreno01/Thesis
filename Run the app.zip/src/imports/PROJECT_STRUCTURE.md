# Smart Harvest - Project Structure & Documentation

## 📁 Project Overview

Smart Harvest is a complete mobile-responsive web application for harvest yield and market price prediction using machine learning. The application is built with React, TypeScript, and Tailwind CSS, with a modular architecture ready for ML model integration.

---

## 🎯 Features

### 1. User Authentication
- **Login/Registration System**
- Secure authentication flow
- User session management
- Demo credentials available

### 2. Dashboard
- Real-time statistics overview
- Total crops, predictions, and revenue tracking
- Recent activity feed
- Quick action buttons
- Market price summary
- Recent crops display

### 3. Crop Data Input
- Comprehensive crop information form
- Fields for crop type, variety, dates, area
- Soil and irrigation parameters
- Environmental conditions (temperature, humidity, rainfall)
- Location selection
- Form validation

### 4. Prediction Results
- AI-powered yield predictions
- Market price predictions
- Confidence scores with factor breakdown
- Generate predictions for any crop
- Visual confidence indicators
- Revenue estimation
- Historical prediction tracking

### 5. Market Price Analysis
- Real-time market prices for multiple crops
- Interactive price history charts (30 days)
- Price trend indicators
- Location-based pricing
- Market insights and analytics
- Tabular and chart views

---

## 📂 File Structure

```
/src
├── /app
│   ├── App.tsx                      # Main application entry point
│   ├── routes.ts                    # React Router configuration
│   │
│   ├── /components
│   │   ├── /figma
│   │   │   └── ImageWithFallback.tsx  # Protected image component
│   │   └── /ui                        # Reusable UI components
│   │       ├── button.tsx
│   │       ├── card.tsx
│   │       ├── input.tsx
│   │       ├── label.tsx
│   │       ├── select.tsx
│   │       ├── tabs.tsx
│   │       ├── badge.tsx
│   │       ├── progress.tsx
│   │       └── ... (30+ UI components)
│   │
│   ├── /pages
│   │   ├── Root.tsx                 # Root layout with navigation
│   │   ├── Login.tsx                # Login page
│   │   ├── Register.tsx             # Registration page
│   │   ├── Dashboard.tsx            # Main dashboard
│   │   ├── CropInput.tsx            # Crop data entry form
│   │   ├── PredictionResults.tsx    # Predictions display
│   │   └── MarketPrices.tsx         # Market analysis
│   │
│   └── /services
│       └── api.ts                   # API service layer (mock + real)
│
├── /styles
│   ├── index.css                    # Main styles
│   ├── tailwind.css                 # Tailwind imports
│   ├── theme.css                    # Theme variables
│   └── fonts.css                    # Font imports
│
└── /imports
    ├── BACKEND_INTEGRATION.md       # Backend integration guide
    ├── PROJECT_STRUCTURE.md         # This file
    └── smart-harvest-app.md         # Original requirements
```

---

## 🔧 Technology Stack

### Frontend
- **React 18.3.1** - UI framework
- **TypeScript** - Type safety
- **React Router 7** - Client-side routing
- **Tailwind CSS 4** - Styling
- **Radix UI** - Accessible component primitives
- **Recharts** - Data visualization
- **Lucide React** - Icons
- **Sonner** - Toast notifications

### State Management
- React hooks (useState, useEffect)
- React Router navigation state
- Local state management (ready for Redux/Context API)

### Development Tools
- **Vite** - Build tool
- **PostCSS** - CSS processing
- **ESLint** - Code linting

---

## 🚀 Getting Started

### Running the Application

The application is already running in Figma Make. Navigate through:
1. **Login Page** (`/`) - Start here with demo credentials
2. **Dashboard** (`/dashboard`) - Overview of your farming data
3. **Add Crop** (`/crop-input`) - Enter crop information
4. **Predictions** (`/predictions`) - View AI predictions
5. **Market Prices** (`/market-prices`) - Analyze market trends

### Demo Credentials
- Email: `demo@farmer.com`
- Password: `demo123`

---

## 📊 Data Flow

### 1. Authentication Flow
```
User Input → authService.login() → Store User Session → Navigate to Dashboard
```

### 2. Crop Data Submission
```
Form Input → Validation → cropService.submitCropData() → Update State → Navigate to Predictions
```

### 3. Prediction Generation
```
Select Crop → predictionService.getPrediction() → ML Model Processing → Display Results
```

### 4. Market Price Updates
```
Load Component → marketService.getMarketPrices() → Display Cards & Charts → Refresh on Demand
```

---

## 🤖 Machine Learning Integration

### Current Implementation
The app includes a **comprehensive mock ML service** that demonstrates:
- Feature preparation from crop data
- Multi-factor prediction algorithms
- Confidence score calculations
- Factor breakdown (weather, soil, historical)

### Backend Integration Points
Located in `/src/app/services/api.ts`:

```typescript
// Ready for backend API replacement
export const predictionService = {
  async getPrediction(cropId: string): Promise<Prediction> {
    // TODO: Replace with actual backend call
    const response = await fetch(`${API_URL}/api/predictions/${cropId}`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  }
}
```

### ML Model Integration Steps
1. **Train your model** using historical harvest data
2. **Export model** as `.pkl` (scikit-learn) or `.h5` (TensorFlow)
3. **Set up backend API** (see BACKEND_INTEGRATION.md)
4. **Update frontend services** to call real endpoints
5. **Deploy and test** with real data

---

## 🎨 Design System

### Color Palette
- **Primary**: Green shades (agriculture theme)
- **Secondary**: Blue shades (data/tech theme)
- **Accent**: Purple, Yellow (highlights)
- **Neutrals**: Gray scale

### Typography
- System fonts with fallbacks
- Responsive font sizes
- Semantic heading hierarchy

### Components
All components follow:
- Accessibility standards (ARIA labels)
- Responsive design principles
- Consistent spacing and sizing
- Dark/light mode ready (via theme.css)

---

## 📱 Responsive Design

The application is fully responsive with breakpoints:
- **Mobile**: < 640px (sm)
- **Tablet**: 640px - 1024px (md/lg)
- **Desktop**: > 1024px (xl)

### Mobile Optimizations
- Collapsible navigation menu
- Touch-friendly buttons and inputs
- Optimized chart rendering
- Stacked card layouts

---

## 🔐 Security Considerations

### Current Implementation (Mock)
- Client-side validation
- Demo authentication
- Mock data storage

### Production Requirements
- Implement JWT authentication
- Secure password hashing (bcrypt)
- HTTPS only
- Input sanitization
- CSRF protection
- Rate limiting
- Secure API keys

---

## 📈 Future Enhancements

### Phase 1 (Current)
✅ Frontend application with mock data
✅ Complete UI/UX flow
✅ Chart visualizations
✅ Responsive design

### Phase 2 (Backend Integration)
- [ ] Connect to Python FastAPI backend
- [ ] PostgreSQL database setup
- [ ] Real authentication system
- [ ] File upload for datasets

### Phase 3 (ML Integration)
- [ ] Train ML models with collected data
- [ ] Deploy models to backend
- [ ] Real-time predictions
- [ ] Model performance monitoring

### Phase 4 (Advanced Features)
- [ ] Weather API integration
- [ ] Satellite imagery analysis
- [ ] Multi-language support
- [ ] Mobile app (React Native)
- [ ] Farmer community features
- [ ] Export reports (PDF)

---

## 🧪 Testing Strategy

### Recommended Tests
1. **Unit Tests**: Individual components and services
2. **Integration Tests**: User flows (login → add crop → predict)
3. **E2E Tests**: Complete application workflows
4. **API Tests**: Backend endpoint validation
5. **ML Model Tests**: Prediction accuracy and performance

### Testing Tools
- Jest + React Testing Library (unit/integration)
- Cypress or Playwright (E2E)
- Pytest (backend)

---

## 📚 API Documentation

### Mock API Structure
All API functions are in `/src/app/services/api.ts`:

- `authService`: Login, register, logout
- `cropService`: CRUD operations for crops
- `predictionService`: Generate and retrieve predictions
- `marketService`: Market prices and historical data
- `dashboardService`: Statistics and aggregations

### Future Backend API
See `BACKEND_INTEGRATION.md` for:
- Complete endpoint specifications
- Request/response schemas
- Authentication flow
- Database queries
- ML model integration code

---

## 🌐 Deployment Guide

### Frontend Deployment
1. **Build**: `npm run build`
2. **Deploy to**:
   - Vercel (recommended)
   - Netlify
   - AWS Amplify
   - GitHub Pages

### Backend Deployment
1. **Containerize**: Use Docker
2. **Deploy to**:
   - AWS EC2 / ECS
   - Google Cloud Run
   - Heroku
   - DigitalOcean

### Database Hosting
- AWS RDS
- Google Cloud SQL
- Supabase
- PlanetScale

---

## 🤝 Contributing

### Code Standards
- Use TypeScript for type safety
- Follow React best practices
- Write meaningful component names
- Comment complex logic
- Keep components under 300 lines

### Git Workflow
1. Create feature branch
2. Implement changes
3. Test thoroughly
4. Submit pull request
5. Code review
6. Merge to main

---

## 📞 Support & Documentation

### Resources
- React Documentation: https://react.dev
- React Router: https://reactrouter.com
- Tailwind CSS: https://tailwindcss.com
- Recharts: https://recharts.org
- FastAPI: https://fastapi.tiangolo.com
- scikit-learn: https://scikit-learn.org

### Thesis Documentation Tips
1. **Architecture Diagrams**: Show system components
2. **Flow Charts**: Illustrate user workflows
3. **Screenshots**: Capture each page/feature
4. **Code Snippets**: Include key algorithms
5. **Results**: Show prediction accuracy
6. **Comparison**: Compare with existing solutions

---

## ✅ Project Checklist

### Frontend (Completed)
- [x] User authentication pages
- [x] Dashboard with statistics
- [x] Crop data input form
- [x] Prediction results display
- [x] Market price analysis
- [x] Responsive design
- [x] Navigation system
- [x] Mock API layer
- [x] Chart visualizations
- [x] Toast notifications

### Backend (To Implement)
- [ ] Database schema setup
- [ ] RESTful API endpoints
- [ ] Authentication system
- [ ] ML model loading
- [ ] Data validation
- [ ] Error handling
- [ ] Logging system

### ML/Data (To Implement)
- [ ] Dataset collection
- [ ] Data preprocessing
- [ ] Feature engineering
- [ ] Model training
- [ ] Model evaluation
- [ ] Model deployment
- [ ] Continuous learning

---

## 📝 License

This is a thesis project for educational purposes.

---

## 🎓 Academic Context

### Thesis Title
"Smart Harvest and Market Price Prediction System using Machine Learning"

### Objectives
1. Develop a user-friendly web application for farmers
2. Integrate machine learning for harvest yield prediction
3. Provide market price forecasting
4. Enable data-driven farming decisions
5. Demonstrate scalable architecture for ML deployment

### Technologies Demonstrated
- Full-stack web development
- Machine learning integration
- Database design
- RESTful API architecture
- Responsive UI/UX design
- Cloud deployment strategies

---

**Version**: 1.0.0  
**Last Updated**: March 3, 2026  
**Status**: Frontend Complete, Backend Ready for Integration
