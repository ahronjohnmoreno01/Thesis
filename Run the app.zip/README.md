
  # Run the app

  This is a code bundle for Run the app. The original project is available at https://www.figma.com/design/iCpwMjcZ1V36YRFbCJM9Ty/Run-the-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  